from random import randint

borda = []

for x in range(10):
    borda.append(["O"] * 10)

def print_borda(borda):
    for linha in borda:
        print(" ".join(linha))

print("\nJogo Batalha Naval!\n")
print_borda(borda)

def linha_aleatoria(borda):
    return randint(0, len(borda) - 1)

def coluna_aleatoria(borda):
    return randint(0, len(borda[0]) - 1)

navio_linha = linha_aleatoria(borda)
navio_coluna = coluna_aleatoria(borda)

for turn in range(10):
    linha = int(input("\nEscolha uma linha para jogar: "))
    coluna = int(input("\nEscolha uma coluna para jogar: "))

    if coluna == linha and coluna == coluna:
        print("\nParabéns! Você afundou um navio!")
        break

    else:
        if (linha < 0 or linha > 10) or (coluna < 0 or coluna > 10):
            print("\nEssa cassa não está no oceano!")

        elif(borda[linha][coluna] == "X"):
            print("\nVocê já achou esse navio!")

        else:
            print("\nVocê achou um navio!")
            borda[linha][coluna] = "X"

        print (turn + 1)
        print_borda(borda)

        if turn > 10:
            print("\nJogo finalizado, você perdeu!")

print("\nA localização do navio é", navio_linha)
print(navio_coluna)